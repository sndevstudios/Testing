NEPTUN PLAYGROUND - local simulation edition

HOW TO RUN
1. Extract the whole ZIP archive into one folder.
2. Open index.html in a modern browser (Chrome, Firefox, Edge).
3. Press the PLAYGROUND button in the lower-right corner.

WHAT WAS ADDED
- A local-only simulation panel with 27 region status switches.
- Bulk enable and reset controls.
- A small session event log and active-status counter.
- A permanent SIMULATION ONLY watermark while the panel is open or simulated statuses are active.

IMPORTANT
- This is a saved static copy of the original NEPTUN page with an extra local playground panel.
- The simulation only changes fictional region status labels inside the current browser tab.
- No simulated status is sent to any server. No real alerts, notifications, aircraft, drones, weapons, or routes are simulated.
- The original live map may not fully load from a static archive because its map tiles and live data depend on external services and the original site's backend.
- Always rely on official alerts for real-world safety.
- This is an unofficial fan modification and is not affiliated with NEPTUN.
