/* NEPTUN Playground - local-only training UI. No network calls, no real alert data. */
(() => {
  'use strict';
  if (window.__NEPTUN_PLAYGROUND__) return;
  window.__NEPTUN_PLAYGROUND__ = true;

  const regions = [
    'Вінницька область','Волинська область','Дніпропетровська область','Донецька область',
    'Житомирська область','Закарпатська область','Запорізька область','Івано-Франківська область',
    'Київська область','Кіровоградська область','Луганська область','Львівська область',
    'Миколаївська область','Одеська область','Полтавська область','Рівненська область',
    'Сумська область','Тернопільська область','Харківська область','Херсонська область',
    'Хмельницька область','Черкаська область','Чернівецька область','Чернігівська область',
    'м. Київ','АР Крим','м. Севастополь'
  ];
  const active = new Set();
  const log = [];
  let isOpen = false;
  let toastTimer = null;

  const el = (tag, attrs = {}, content = '') => {
    const node = document.createElement(tag);
    Object.entries(attrs).forEach(([key, value]) => {
      if (key === 'className') node.className = value;
      else if (key === 'text') node.textContent = value;
      else node.setAttribute(key, value);
    });
    if (content) node.innerHTML = content;
    return node;
  };

  const launcher = el('button', { id:'np-playground-launcher', type:'button', 'aria-expanded':'false', 'aria-controls':'np-playground-panel' });
  launcher.innerHTML = '<span class="np-launch-icon" aria-hidden="true">⌘</span><span class="np-launch-copy"><span>PLAYGROUND</span><small>NEPTUN SIMULATOR</small></span><span class="np-launch-count" id="np-launch-count">0</span>';

  const watermark = el('div', { id:'np-playground-watermark', 'aria-hidden':'true' }, 'SIMULATION ONLY · LOCAL DATA');
  const panel = el('section', { id:'np-playground-panel', role:'dialog', 'aria-modal':'false', 'aria-labelledby':'np-panel-title' });
  panel.innerHTML = `
    <header class="np-head">
      <div class="np-brand">
        <div class="np-brand-mark" aria-hidden="true">N</div>
        <div>
          <h2 class="np-title" id="np-panel-title">NEPTUN PLAYGROUND</h2>
          <p class="np-subtitle">Тренувальна панель · локальна симуляція</p>
          <span class="np-sim-tag">SIMULATION MODE</span>
        </div>
      </div>
      <button class="np-close" type="button" aria-label="Закрити панель">×</button>
    </header>
    <div class="np-body">
      <p class="np-warning"><strong>Це не справжня карта тривог.</strong> Усі статуси вигадані, існують лише в цій вкладці та не надсилаються на сервер. Для реальної безпеки користуйся офіційними сповіщеннями.</p>
      <div class="np-stats" aria-live="polite">
        <div class="np-stat"><strong id="np-stat-total">27</strong><span>регіонів у панелі</span></div>
        <div class="np-stat"><strong id="np-stat-active">0</strong><span>умовних тривог</span></div>
        <div class="np-stat"><strong id="np-stat-events">0</strong><span>змін у сесії</span></div>
      </div>
      <div class="np-section-head"><h3>Статуси регіонів</h3><small>Натисни на область, щоб перемкнути</small></div>
      <div class="np-actions">
        <button class="np-action primary" id="np-enable-all" type="button">Увімкнути всі</button>
        <button class="np-action" id="np-reset" type="button">Скинути все</button>
      </div>
      <div class="np-regions" id="np-regions" aria-label="Навчальні статуси регіонів"></div>
      <div class="np-section-head"><h3>Журнал симуляції</h3><small>Останні події</small></div>
      <div class="np-log" id="np-log" aria-live="polite"><div class="np-log-empty">Поки що змін не було.</div></div>
      <div class="np-footer">Схематичний список регіонів, не географічна карта. NEPTUN PLAYGROUND — неофіційна локальна модифікація з навчальними статусами; не пов’язана з оператором оригінального сайту.</div>
    </div>`;
  const toast = el('div', { id:'np-playground-toast', role:'status', 'aria-live':'polite' });

  document.body.append(launcher, watermark, panel, toast);

  const regionContainer = panel.querySelector('#np-regions');
  const statActive = panel.querySelector('#np-stat-active');
  const statEvents = panel.querySelector('#np-stat-events');
  const logContainer = panel.querySelector('#np-log');
  const countBadge = launcher.querySelector('#np-launch-count');

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2100);
  }

  function addLog(message) {
    const now = new Date();
    log.unshift({ message, time: now.toLocaleTimeString('uk-UA', { hour:'2-digit', minute:'2-digit', second:'2-digit' }) });
    if (log.length > 8) log.length = 8;
    renderLog();
  }

  function renderLog() {
    logContainer.replaceChildren();
    if (!log.length) {
      logContainer.append(el('div', { className:'np-log-empty', text:'Поки що змін не було.' }));
      return;
    }
    log.forEach(item => {
      const row = el('div', { className:'np-log-item' });
      row.append(el('time', { text:item.time }), el('span', { text:item.message }));
      logContainer.append(row);
    });
  }

  function render() {
    regionContainer.replaceChildren();
    regions.forEach(name => {
      const on = active.has(name);
      const button = el('button', {
        className:'np-region', type:'button', 'aria-pressed':String(on),
        'aria-label':`${name}: ${on ? 'умовна тривога' : 'спокійно'}`
      });
      button.append(el('span', { text:name }), el('span', { className:'np-state', text:on ? 'SIM · ТРИВОГА' : 'SIM · ЧИСТО' }));
      button.addEventListener('click', () => {
        if (active.has(name)) {
          active.delete(name);
          addLog(`${name}: умовний статус скасовано`);
          showToast(`Умовний статус скасовано: ${name}`);
        } else {
          active.add(name);
          addLog(`${name}: увімкнено умовну тривогу`);
          showToast(`Увімкнено навчальний статус: ${name}`);
        }
        render();
      });
      regionContainer.append(button);
    });
    statActive.textContent = String(active.size);
    statEvents.textContent = String(log.length);
    countBadge.textContent = String(active.size);
    launcher.classList.toggle('has-alerts', active.size > 0);
    watermark.classList.toggle('visible', isOpen || active.size > 0);
  }

  function setOpen(next) {
    isOpen = next;
    panel.classList.toggle('open', isOpen);
    launcher.setAttribute('aria-expanded', String(isOpen));
    watermark.classList.toggle('visible', isOpen || active.size > 0);
    if (isOpen) panel.querySelector('.np-close').focus({ preventScroll:true });
    else launcher.focus({ preventScroll:true });
  }

  launcher.addEventListener('click', () => setOpen(!isOpen));
  panel.querySelector('.np-close').addEventListener('click', () => setOpen(false));
  panel.querySelector('#np-enable-all').addEventListener('click', () => {
    const newlyEnabled = regions.filter(name => !active.has(name)).length;
    regions.forEach(name => active.add(name));
    if (newlyEnabled) addLog(`Увімкнено умовні статуси для ${newlyEnabled} регіонів`);
    render();
    showToast('Увімкнено навчальні статуси для всіх регіонів');
  });
  panel.querySelector('#np-reset').addEventListener('click', () => {
    const count = active.size;
    active.clear();
    if (count) addLog(`Скинуто всі умовні статуси (${count})`);
    render();
    showToast('Симуляцію скинуто');
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && isOpen) setOpen(false);
  });

  render();
})();
